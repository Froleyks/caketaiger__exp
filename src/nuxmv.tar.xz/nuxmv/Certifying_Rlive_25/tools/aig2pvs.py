from simplic3 import *
import argparse
import sys
import os
import re
from contextlib import contextmanager


def getopts(args=None):
    p = argparse.ArgumentParser()
    p.add_argument('filename')
    p.add_argument('-o', '--output')
    p.add_argument('-i', '--invar')
    p.add_argument('-s', '--symboltable', action='store_true', default=True)
    p.add_argument('-n', '--no-symboltable', dest='symboltable',
                   action='store_false')
    p.add_argument('-m', '--mode', choices=['phaseabs', 'plain', 'td', 'rlive'],
                   default='plain')
    p.add_argument('-t', '--td-depth', type=int)
    return p.parse_args(args)


@contextmanager
def open_if(filename):
    if filename is not None:
        f =  open(filename, 'w')
        try:
            yield f
        finally:
            f.close()
    else:
        yield sys.stdout


def main(args=None):
    opts = getopts(args)
    aigmgr = aiger_init()
    err = aiger_open_and_read_from_file(aigmgr, opts.filename)
    if err:
        raise Exception(err)
    with open_if(opts.output) as out:
        pr = out.write
        cache = {}
        state = []
        name2lit = {}
        for i in range(aiger_num_latches(aigmgr)):
            l = aiger_get_latch(aigmgr, i)
            n = f'l{aiger_lit2var(l.lit)}'
            cache[l.lit] = n
            state.append(n)
            if opts.symboltable:
                name2lit[l.name] = l.lit
        inp = []
        for i in range(aiger_num_inputs(aigmgr)):
            l = aiger_get_input(aigmgr, i)
            n = f'i{aiger_lit2var(l.lit)}'
            cache[l.lit] = n
            inp.append(n)
        name = 'test' if not opts.output \
            else os.path.splitext(os.path.basename(opts.output))[0]
        pr(f'{name}[State: TYPE+]: THEORY\nBEGIN\n')
        pr('IMPORTING shallow_ltl[State], lemmas_shallow_ltl[State]\n')
        for v in state + inp:
            pr(f'{v} : ltlformula\n')
        def get(lit):
            if lit == 0: return 'FF_bool'
            elif lit == 1: return 'TT_bool'
            l = aiger_strip(lit)
            res = cache[l]
            return res if not aiger_sign(lit) else f'NOT_bool({res})'
        ands = []
        for i in range(aiger_num_ands(aigmgr)):
            l = aiger_get_and(aigmgr, i)
            v = aiger_lit2var(l.lhs)
            cache[l.lhs] = f'a{v}'
            ands.append((v, f'AND_bool({get(l.rhs0)}, {get(l.rhs1)})'))
        for v, d in ands:
            pr(f'a{v} : ltlformula = {d}\n')
        pr('\n')

        has_constr = False
        if aiger_num_constraints(aigmgr) > 0:
            has_constr = True
            for i in range(aiger_num_constraints(aigmgr)):
                c = aiger_get_constraint(aigmgr, i)
                cc = get(c.lit)
                if i > 0:
                    pr(f'constr{i} = AND_bool(constr{i-1}, {cc})\n')
                else:
                    pr(f'constr{i} = {cc}\n')
            pr(f'constr : ltlformula = constr{i}\n\n')
            
        def iff(l, v):
            if v == 0:
                return f'NOT_bool({l})'
            elif v == 1:
                return l
            else:
                return f'IFF_bool({l}, {get(v)})'
            
        for i in range(aiger_num_latches(aigmgr)):
            l = aiger_get_latch(aigmgr, i)
            v = aiger_lit2var(l.lit)
            e = iff(f'l{v}', l.reset)
            if i > 0:
                pr(f'init{i} : ltlformula = AND_bool(init{i-1}, {e})\n')
            else:
                pr(f'init{i} : ltlformula = {e}\n')
        if has_constr:
            pr(f'init : ltlformula = AND_bool(init{i}, constr)\n\n')
        else:
            pr(f'init : ltlformula = init{i}\n\n')
            
        for i in range(aiger_num_latches(aigmgr)):
            l = aiger_get_latch(aigmgr, i)
            v = aiger_lit2var(l.lit)                
            e = iff(f'NEXT_bool(l{v})', l.next)
            if i > 0:
                pr(f'trans{i} : ltlformula = AND_bool(trans{i-1}, {e})\n')
            else:
                pr(f'trans{i} : ltlformula = {e}\n')
        if has_constr:
            pr(f'trans : ltlformula = AND_bool(trans{i}, constr)\n\n')
        else:
            pr(f'trans : ltlformula = trans{i}\n\n')

        if opts.mode != 'rlive':
            assert aiger_num_bad(aigmgr) >= 1 or aiger_num_outputs(aigmgr) >= 1
            b = aiger_get_bad(aigmgr, 0) if aiger_num_bad(aigmgr) >= 1 \
                else aiger_get_output(aigmgr, 0)
            if has_constr:
                pr(f'bad : ltlformula = AND_bool(constr, {get(b.lit)})\n')
            else:
                pr(f'bad : ltlformula = {get(b.lit)}\n')
            pr(f'prop : ltlformula = NOT_bool(bad)\n')
        else:
            assert aiger_num_justice(aigmgr) == 1 \
                   and aiger_num_fairness(aigmgr) == 0
            assert not has_constr
            q = aiger_get_justice(aigmgr, 0)
            assert q.size == 1 \
                or (q.size == 2 and aiger_get_lit(q, 0) == aiger_true)
            qlit = aiger_get_lit(q, 0 if q.size == 1 else 1)
            pr(f'Q : ltlformula = NOT_bool({get(qlit)})\n')
        aiger_reset(aigmgr)
        pr('\n')

        td_depth = opts.td_depth
        if opts.invar:
            aigmgr = aiger_init()
            err = aiger_open_and_read_from_file(aigmgr, opts.invar)
            if not err:
                #assert aiger_num_outputs(aigmgr) == 1
                cache.clear()
                for i in range(aiger_num_inputs(aigmgr)):
                    l = aiger_get_input(aigmgr, i)
                    i = l.lit if not opts.symboltable else name2lit[l.name]
                    n = f'l{aiger_lit2var(i)}'
                    cache[l.lit] = n
                ands = []
                for i in range(aiger_num_ands(aigmgr)):
                    l = aiger_get_and(aigmgr, i)
                    v = aiger_lit2var(l.lhs)
                    cache[l.lhs] = f'inv{v}'
                    ands.append((v, f'AND_bool({get(l.rhs0)}, {get(l.rhs1)})'))
                for v, d in ands:
                    pr(f'inv{v} : ltlformula = {d}\n')
                if opts.mode == 'rlive':
                    shoals = []
                    for i in range(aiger_num_outputs(aigmgr)):
                        o = aiger_get_output(aigmgr, i)
                        shoals.append(get(o.lit))
                    invar = shoals[-1]
                    shoals.pop()
                    pr('\n')
                    pr(f'c: [nat -> ltlformula] = \n')
                    pr(' LAMBDA (i: nat): IF i = 0 THEN FF_bool ELS')
                    for i, s in enumerate(shoals):
                        pr(f'IF i = {i+1} THEN {s} ELS')
                    pr('E TT_bool ENDIF\n')
                    pr('\n')
                    pr(f'invar : ltlformula = {invar}\n')
                else:
                    inv = aiger_get_output(aigmgr, 0)
                    invar = get(inv.lit)
                    pr(f'invar : ltlformula = {invar}\n')
                    aiger_reset(aigmgr)
                    if opts.mode == 'td' and td_depth is None:
                        m = re.match(r'.*-T([0-9]+)\.aig', opts.invar)
                        if m is not None:
                            td_depth = int(m.group(1))
            else:
                assert opts.mode != 'rlive', err
                with open(opts.invar) as f:
                    invar = None
                    for i, line in enumerate(f):
                        line = line.strip()
                        assert line.startswith('[') and line.endswith(']')
                        clause = line[1:-1].split()
                        c = None
                        for lit in clause:
                            if lit.startswith('~'):
                                l = f'NOT_bool(l{lit[1:]})'
                            else:
                                l = f'l{lit}'
                            c = f'OR_bool({c}, {l})' if c is not None else l
                        if c is not None:
                            pr(f'cls{i} : ltlformula = {c}\n')
                        else:
                            pr(f'cls{i} : ltlformula = TT_bool\n')
                        if i > 0:
                            pr(f'invar{i} : ltlformula = '
                               f'AND_bool(invar{i-1}, cls{i})\n')
                        else:
                            pr(f'invar{i} : ltlformula = cls{i}\n')
                    pr(f'invar : ltlformula = invar{i}\n')
            pr('\n% our theorem\n')
            pr('thm_inv : THEOREM\n')
            if opts.mode == 'rlive':
                pr(f'  valid(=>(AND(init, GLOBALLY(trans)), '
                   f'FINALLY(GLOBALLY(Q))))\n')
                pr(f'%|- thm_inv : PROOF\n')
                pr(f'%|- (rlive$ {len(shoals)} "c" "invar")\n')
            else:
                prop = 'NOT(bad)' if opts.mode == 'plain' else 'prop'
                pr(f'  valid(=>(AND(init, GLOBALLY(trans)), '
                   f'GLOBALLY({prop})))\n')
                pr(f'%|- thm_inv : PROOF\n')
                pr('%|- (then (set-print-depth 10)\n')
                pr('%|- (set-print-length 10)\n')
                pr('%|- (set-print-lines 10)\n')
                pr(f'%|- (auto-rewrite-theory "{name}")\n')
                if opts.mode == 'plain':
                    pr('%|- (general_invariant_shallow_ltl_macro$ "invar") )\n')
                elif opts.mode == 'td':
                    assert td_depth is not None
                    pr(f'%|- (tmp_decomposition_v2$ "{td_depth}" "invar") )\n')
                else:
                    pr('%|- (phase_abstraction_kis2$ "invar") )\n')
            pr('%|- QED\n')
        pr(f'END {name}\n')


if __name__ == '__main__':
    main()
