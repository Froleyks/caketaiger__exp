import os
import argparse
import subprocess
import tempfile
import aig2pvs


def getopts():
    p = argparse.ArgumentParser()
    p.add_argument('--simplic3', help='path to simplic3', required=True)
    p.add_argument('-t', '--tdecomp', type=int)
    p.add_argument('-o', '--output')
    p.add_argument('aig')
    return p.parse_args()


def main():
    opts = getopts()
    with tempfile.TemporaryDirectory() as d:
        print('-' * 80)
        print(f'checking {opts.aig} with simplic3...')
        print('-' * 80)
        simplic3_opts = [
            '-W', '-o', os.path.join(d, 'wit.aag'),
            '-a', 'ic3', '-v', '1', opts.aig
        ]
        if opts.tdecomp:
            simplic3_opts += [
                '-d', str(opts.tdecomp),
                '-t', str(opts.tdecomp),
                '-p', '1',
                '-F', '100000',
            ]
        subprocess.run([opts.simplic3] + simplic3_opts, check=True)
        inv = os.path.join(d, 'wit.aag')
        if os.path.exists(inv):
            print('-' * 80)
            print(f'generating PVS proof script in {opts.output}...')
            print('-' * 80)
            aig2pvs_opts = [
                opts.aig, '-n',
                '-o', opts.output,
                '-i', inv
            ]
            if opts.tdecomp:
                aig2pvs_opts += ['-m', 'td', '-t', str(opts.tdecomp)]
            aig2pvs.main(aig2pvs_opts)

if __name__ == '__main__':
    main()
