;;
;; prelude-attachments.lisp
;; Release: PVSio-8.0 (10/13/2023)
;;
;; Contact: Cesar Munoz (cesar.a.munoz@nasa.gov)
;; NASA Langley Research Center
;; http://shemesh.larc.nasa.gov/people/cam/PVSio
;;
;; Copyright (c) 2011-2012 United States Government as represented by
;; the National Aeronautics and Space Administration.  No copyright
;; is claimed in the United States under Title 17, U.S.Code. All Other
;; Rights Reserved.
;;
;; Semantic attachments for PVSio standard library
;;

(in-package :pvs)

(decimals:define-decimal-formatter z (:round-magnitude (- +pvsio-default-precision+))
				   (:show-trailing-zeros t))
(decimals:define-decimal-formatter d (:round-magnitude (- +pvsio-default-precision+)))

(defvar *pvsio-dummy-val* t)

(defun clos-type2str (the-type)
  "Return string represenation of a PVS type represented in CLOS"
  (format nil "~a" (or (print-type the-type) the-type)))

(defun stdpvs-attachments ()

(eval '(attachments |stdpvs|

(defattach |format_lisp| (s e (the-type :decl-formal |T|))
   "Formats expression E of type T using Common Lisp format string S"
   (unwind-protect
       (progn
	 (pvsio_push_gvar *pvsio-pp_rationals* nil)
	 (apply #'format (cons nil (cons s (formatargs e the-type)))))
     (pvsio_pop_gvar *pvsio-pp_rationals*)))

(defattach |error_lisp| (mssg)
  "Signals the error message MSSG to the ground evaluator"
  (attach-error mssg))

(defattach |exit| ()
  "Exits the current evaluation and returns to the ground evaluator"
  (error 'pvsio-exit))

(defattach |last_iteration| (e (the-type :decl-formal |T|))
  "Breaks a loop with the value E"
  (error 'pvsio-break :val e :type the-type))

(defattach |return| (e (the-type :decl-formal |T|))
  "Returns E as the value of a function call"
  (error 'pvsio-return :val e :type the-type))

(defattach |loop_lift| (f)
   "Applies F in an infinite loop"
   (handler-case
       (loop (pvs-funcall f *pvsio-dummy-val*))
     (pvsio-break
      (condition)
      (val condition))))

(defattach |to_lisp| (pvs)
  "Translates PVS object to Common Lisp"
  pvs)

(defattach |from_lisp| (cl)
  "Translates Common Lisp object to PVS"
 cl)

(defattach |typeof_lisp_| (cl)
  "PVS type of encoded Common Lisp object"
  (cdr cl))

(defattach |unwind_protect_lift| (ft fcu)
  "Evaluate ft, returning its value. The cleanup code fcu will be evaluated if control leaves ft."
  (unwind-protect
      (pvs-funcall ft *pvsio-dummy-val*)
    (pvs-funcall fcu *pvsio-dummy-val*)))

)))

(defun replace-string (string part replacement &key (test #'char=))
  "Returns a new string in which all the occurences of the part
is replaced with replacement."
  (with-output-to-string (out)
    (loop with part-length = (length part)
          for old-pos = 0 then (+ pos part-length)
          for pos = (search part string
                            :start2 old-pos
                            :test test)
          do (write-string string out
                           :start old-pos
                           :end (or pos (length string)))
          when pos do (write-string replacement out)
          while pos)))

;; Oveline: <char> Ctrl-x 8 305
(defparameter *ol-digits* '("0̅" "1̅" "2̅" "3̅" "4̅" "5̅" "6̅" "7̅" "8̅" "9̅"))
(defparameter *ellipsis* '("¨" . "¨̅"))

(defun replace-ol-digits (acc &optional (n 0) (ol *ol-digits*))
  (if (null ol) acc
    (replace-ol-digits (replace-string acc (format nil "~a" n) (car ol))
		       (1+ n) (cdr ol))))

;; Pretty prints decimal using overline to indicate repeating digits. Finp is the precision of the
;; non-repeating digits. Truncated indicates that the infinite representation was truncated.
(defun pp-decstr (str finp truncated)
  (let ((pos (position #\. str)))
    (if pos
	(let* ((fixp (+ pos finp 1))
	       (pre  (subseq str 0 (min fixp (length str))))
	       (pos  (when (< fixp (length str)) (subseq str fixp (length str))))
	       (npos (when pos (replace-ol-digits pos)))
	       (ell  (when truncated (if (>= fixp (length str)) (car *ellipsis*) (cdr *ellipsis*)))))
	  (format nil "~a~@[~a~]~@[~a~]" pre npos ell))
      str)))

(defun pp-rat (r &optional (precision 6))
  "Pretty prints rational numbers using overline to indicate repeating digits and ellipsis when decimal
expansion is truncated. If precision is negative, the rational is printed in decimal representation if the
representation is finite. Otherwise, it prints its rational form."
  (multiple-value-bind (finp infp)
      (decimal-precision-of-rat r (max 0 precision))
    (cond ((and (< precision 0) (= infp 0)) (ratio2decimal-with-rounding-mode r 0 finp))
	  ((< precision 0) (format nil "~a" r))
	  (t (let ((str (ratio2decimal-with-rounding-mode r 0 (min precision (+ finp infp)) t)))
	       (pp-decstr str finp (> (+ finp infp) precision)))))))

(defun stdchar-attachments ()

(eval '(attachments |stdchar|

(defattach |char_compare_lisp| (c1 c2 sensitive)
 "Returns 0 if C1 = C2, -1 if C1 < C2, 1 if C1 > C2. If sensitive is T, comparison is case sensitive."
 (if sensitive
     (cond ((char= c1 c2) 0)
           ((char< c1 c2) -1)
           (t 1))
     (cond ((char-equal c1 c2) 0)
           ((char-lessp c1 c2) -1)
           (t 1))))
)))

(defun stdstr-attachments ()

(eval '(attachments |stdstr|

(defattach |spaces_lisp| (n)
  "N spaces"
  (make-string n :initial-element #\Space))

(defattach |upcase_lisp| (s)
  "Converts string S to uppercase"
  (string-upcase s))

(defattach |downcase_lisp| (s)
  "Converts string S to downcase"
  (string-downcase s))

(defattach |capitalize_lisp| (s)
  "Capitalizes string S"
  (string-capitalize s))

(defattach |strfind_lisp| (s1 s2)
  "Index of leftmost occurrence of S1 in S2 or -1 if S1 doesn't occur in S2"
  (or (search s1 s2 :test #'char=) -1))

(defattach |strfind_from_end_lisp| (s1 s2)
  "Index of rightmost occurrence of S1 in S2 or -1 if S1 doesn't occur in S2"
  (or (search s1 s2 :from-end t :test #'char=) -1))

(defattach |strextract_lisp| (s i j)
  "If i <= j returns string S[i..j]. If j <= i, Otherwise, return string S[j..i].
Return empty string if i or j are out of bound.
NOTE: When 0 <= i < j < length(s), strextract(s,i,j) is the same substr(s,i,j+1)."
  (cond ((and (<= 0 i) (<= i j) (< j (length s)))
	 (subseq s i (+ j 1)))
	((and (<= 0 j) (<= j i) (< i (length s)))
	 (reverse (subseq s j (+ i 1))))
	(t "")))

(defattach |strreplace| (s part replacement)
  "Returns a new string in which all the occurences of part in s
is replaced with replacement."
  (replace-string s part replacement))

(defattach |strsplit| (str (separator |char|))
  "Splits the string STR using SEPARATOR as separator."
  (split str separator))

(defattach |rat2decstr_with_zeros| (r precision rounding zeros)
  "Converts rational number to string decimal representation using given precision, i.e., natural number n
denoting 10^(-n), and rounding mode, i.e, TowardsZero, TowardsInfnty, TowardsNegInfnty, TowardsPosInfnty.
Displays trailing zeroes when zeros is set to TRUE"
  (ratio2decimal-with-rounding-mode r rounding precision zeros))

(defattach |pp_decstr| (str finp truncated)
  "Pretty prints decimal using overline to indicate repeating digits. Finp is the precision of the
non-repeating digits. Truncated indicates that the infinite representation was truncated."
  (pp-decstr str finp truncated))

(defattach |decstr2rat| (s)
  "Converts string representing a decimal number to rational number"
  (handler-case
      (decimals:parse-decimal-number s)
    (decimals:decimal-parse-error
     (condition)
     (declare (ignore condition))
     (throw-pvsio-exc "stdexceptions.NotARealNumber" s))))

(defattach |str2real| (s)
  "Rational denoted by S"
  (handler-case
      (decimals:parse-decimal-number s)
    (decimals:decimal-parse-error
     (condition)
     (declare (ignore condition))
     (let ((n (read-from-string s)))
       (cond ((rationalp n) n)
	     ((floatp n) (rationalize n))
	     (t (throw-pvsio-exc "stdexceptions.NotARealNumber" s)))))))

(defattach |str2int| (s)
  "Integer denoted by S"
  (let ((i (read-from-string s)))
    (if (integerp i) i
      (throw-pvsio-exc "stdexceptions.NotAnInteger" s))))

(defattach |number?| (s)
  "Tests if S denotes a number"
  (numberp (read-from-string s)))

(defattach |int?| (s)
  "Tests if S denotes an integer"
  (integerp (read-from-string s)))

(defprimitive |strconcat_lisp| (s1 s2)
  "Concatenates S1 and S2"
  (format nil "~a~a" s1 s2))

(defattach |strcompare_lisp| (s1 s2 sensitive)
  "Returns 0 if S1 = S2, -1 if S1 < S2, 1 if S1 > S2. If sensitive is T, comparison is case sensitive."
  (if sensitive
      (cond ((string= s1 s2) 0)
	    ((string< s1 s2) -1)
	    (t 1))
    (cond ((string-equal s1 s2) 0)
	  ((string-lessp s1 s2) -1)
	  (t 1))))

(defattach |strtrim| (s1 s2)
   "A substring of s2, with all the characters in s1 stripped of the beginning and end"
   (string-trim s1 s2))

(defattach |strtrim_left| (s1 s2)
   "A substring of s2, with all the characters in s1 stripped of the beginning"
   (string-left-trim s1 s2))

(defattach |strtrim_right| (s1 s2)
   "A substring of s2, with all the characters in s1 stripped of the end"
   (string-right-trim s1 s2))

(defattach |trim| (s)
   "A substring of s, with all the space characters stripped of the beginning and end"
   (string-trim '(#\Space #\Tab #\Newline) s))

(defattach |trim_left| (s)
   "A substring of s, with all the space characters stripped of the beginning"
   (string-left-trim '(#\Space #\Tab #\Newline) s))

(defattach |trim_right| (s)
   "A substring of s, with all the space characters stripped of the end"
   (string-right-trim '(#\Space #\Tab #\Newline) s))

(defattach |type2str| ((the-type :decl-formal |T|))
 "Returns the string value of the type T"
 (clos-type2str the-type))

(defattach |subtypeof?| (t1 t2)
  "Returns TRUE if T1 is a subtype of T2 (types are represented using strings).
Uses subtype judgements, but otherwise it's essentially syntactic."
  (let ((the-type1 (pc-typecheck (pc-parse t1 'type-expr)))
	(the-type2 (pc-typecheck (pc-parse t2 'type-expr))))
    (subtype-of? the-type1 the-type2)))

(defattach |str2pvs| (s)
  "Translates string S to PVS format"
  (eval (pvs2cl (pc-typecheck (pc-parse s 'expr)))))

(defattach |pvs2str| (e (the-type :decl-formal |T|))
  "Translates PVS expresion E to a string"
  (handler-case
      (unwind-protect
	  (progn
	    (pvsio_push_gvar *pvsio-pp_rationals* nil)
	    (str (cl2pvs e (pc-typecheck the-type))))
	(pvsio_pop_gvar *pvsio-pp_rationals*))
    (groundeval-error
     (condition)
     (declare (ignore condition))
     (throw-pvsio-exc "stdexceptions.PVS2String" (format nil "~s" e)))))
)))

(defun prompt (s)
  (when (string/= s "")
    (format t "~a~%" s)
    (finish-output))
  (clear-input))

(defparameter *pvsio_length_str_stream* (make-hash-table))

(defun read-token (f s)
  (let* ((c (read-char f nil nil))
	 (stream
	  (when c
	    (do* ((str   (make-string-output-stream))
		  (start t))
		((not c) str)
	      (let ((p (when c (position c s)))
		    (m (when c (member c '(#\Space #\Tab #\Newline)))))
		(cond ((and start p)(write-char c str)
		       (return str))
		      (p (unread-char c f)
			 (return str))
		      ((and start m) (setq c (read-char f nil nil)))
		      (m (return str))
		      (t (setq start nil)
			 (write-char c str)
			 (setq c (read-char f nil nil)))))))))
    (when stream (get-output-stream-string stream))))

(defun stdio-attachments ()

(eval '(attachments |stdio|

(defprimitive |printstr| (s)
  "Prints lisp format of string S"
  (not (format t "~a" s)))

(defattach |query_token| (mssg s)
  "Queries a token separated by characters in S from standard input with prompt MSSG"
  (prompt mssg)
  (format nil "~a" (read-token *standard-input* s)))

(defattach |query_line| (mssg)
  "Queries a line from standard input with prompt MSSG"
  (prompt mssg)
  (format nil "~a" (read-line)))

(defattach |query_real| (mssg)
  "Queries a real number from standard input with prompt MSSG"
  (prompt mssg)
  (let ((i (read)))
    (if (numberp i) (rational i)
      (throw-pvsio-exc "stdexceptions.NotARealNumber" (format nil "~a" i)))))

(defattach |query_int| (mssg)
  "Queries an integer from standard input with prompt MSSG"
  (prompt mssg)
  (let ((i (read)))
    (if (integerp i) i
      (throw-pvsio-exc "stdexceptions.NotAnInteger" (format nil "~a" i)))))

(defattach |stdin| ()
  "Standard input stream"
  *standard-input*)

(defattach |stdout| ()
  "Standard output stream"
  *standard-output*)

(defattach |stderr| ()
  "Error output stream"
  *error-output*)

(defattach |fopenin_lisp| (s)
  "Opens file input stream named S"
  (let ((f (open s :direction :input :if-does-not-exist nil)))
    (or f (throw-pvsio-exc "stdexceptions.FileNotFound" s))))

(defattach |sopenin| (s)
  "Opens string S as an input stream"
  (let ((str (make-string-input-stream s)))
    (setf (gethash str *pvsio_length_str_stream*) (length s))
    str))

(defattach |fopenout_lisp| (s i)
  "Opens file output stream named S"
 (cond ((= i 0) (let ((f (open s :direction :output :if-exists nil)))
		  (or f (throw-pvsio-exc "stdexceptions.FileAlreadyExists" s))))
       ((= i 1) (open s :direction :output :if-exists :supersede))
       ((= i 2) (open s :direction :output :if-exists :append))
       ((= i 3) (open s :direction :output :if-exists :overwrite))))

(defattach |sopenout| (s)
  "Opens string output stream"
  (let ((f (make-string-output-stream)))
    (format f s)
    f))

(defattach |fclose| (f)
  "Closes stream F"
  (or (when (typep f 'file-stream)
	(close f))
      t))

(defattach |fexists| (s)
  "Tests if file named S already exists"
  (and (probe-file s) t))

(defattach |fopen?| (f)
  "Tests if stream F is open"
  (open-stream-p f))

(defattach |strstream?| (f)
  "Tests if F is a string stream"
  (typep f 'string-stream))

(defattach |filestream?| (f)
  "Tests if F is a file stream"
  (typep f 'file-stream))

(defattach |finput?| (f)
  "Tests if F is an input string"
  (input-stream-p f))

(defattach |foutput?| (f)
  "Tests if F is an output string"
  (output-stream-p f))

(defattach |fname_lisp| (f)
  "Get the name of a file stream"
  (namestring f))

(defattach |frename| (oldname newname)
  "Rename a file stream named oldname with newname. Return long newname"
  (handler-case
      (namestring (rename-file oldname newname))
    (error (condition)
      (declare (ignore condition))
      (throw-pvsio-exc "stdexceptions.FileNotFound" oldname))))

(defattach |fgetstr_lisp| (f)
  "Gets string from string output stream F"
  (if (typep f 'string-stream)
      (get-output-stream-string f)
    ""))

(defattach |eof_lisp| (f)
  "Tests end of input stream F"
  (not (peek-char nil f nil nil)))

(defattach |flength_lisp| (f)
  "Length of stream F"
  (cond ((typep f 'file-stream)   (file-length f))
	((typep f 'string-stream)
	 (nth-value 0 (gethash f *pvsio_length_str_stream*)))
	(t 0)))

(defattach |fgetpos_lisp| (f)
  "Gets current position of file stream F"
  (if (typep f 'file-stream)
      (file-position f)
    0))

(defattach |fsetpos_lisp| (f n)
  "Set current position of file stream F"
  (when (typep f 'file-stream)
    (cond ((<= n 0) (file-position f :start))
	  ((>= n (file-length f)) (file-position f :end))
	  (t (file-position f n)))))

(defattach |fprint_lisp| (f s)
  "Prints S in stream F"
  (not (format f "~a" s)))

(defattach |fread_token_lisp| (f s)
  "Reads a token from stream F separated by characters in S"
  (format nil "~a" (read-token f s)))

(defattach |fread_line_lisp| (f)
  "Reads a line from stream F"
  (let ((s (read-line f nil nil)))
    (format nil "~a" s)))

(defattach |fread_real_lisp| (f)
  "Reads a real number from stream F"
  (let ((i (read f nil nil)))
    (when i
      (if (numberp i) (rational i)
        (throw-pvsio-exc "stdexceptions.NotARealNumber" (format nil "~a" i))))))

(defattach |fread_int_lisp| (f)
  "Reads an integer from stream F"
  (let ((i (read f nil nil)))
    (when i
      (if (integerp i) i
        (throw-pvsio-exc "stdexceptions.NotAnInteger" (format nil "~a" i))))))

(defattach |filename| (s)
  "Returns the name part of a file name"
  (or (file-namestring s) ""))

(defattach |directory| (s)
  "Returns the directory part of a file name"
  (directory-namestring s))

(defattach |pathname_path| (name)
   "Path (list of directories) of pathname"
   (let ((dirs (pathname-directory name)))
     (if (equal (car dirs) ':absolute)
         (cons "/" (cdr dirs))
       (cdr dirs))))

(defattach |fwrite_lisp| (f pvs)
  "Writes a PVS object to output stream F of type TYP, so that it
can be retrieved afterwards by fread"
  (or (format f "~s~%" pvs) t))

(defattach |fread_lisp| (f)
  "Reads an PVS object of type TYP from an input stream F, which has been
written by fwrite"
  (read f))

)))

(defun rat2double (x)
  (float x 1.0d0))

(defun stdmath-attachments ()

(eval '(attachments |stdmath|

(defattach |PRECISION| ()
  "Default precision, understood as 10^(-val(PRECISION)), for computations and printing"
  *pvsio-precision*)

(defattach |PP_RATIONALS| ()
  "Default flag for pretty-printing rational numbers"
  *pvsio-pp_rationals*)

(defattach |RANDOM_lisp| ()
  "Real random number in the interval [0..1]"
  (rational (random (rat2double 1))))

(defattach |NRANDOM_lisp| (x)
  "Natural random number in the interval [0..X)"
  (random x))

(defattach |rational_lisp| (x)
  "Returns a rational number that is close to the real number (identity when input is rational)"
  (if (floatp x) (rationalize x) x))

(defprimitive |rat2numden_lisp| (r)
  "Returns numerator and denominator of rational number"
  (pvs2cl_tuple (numerator r) (denominator r)))

(defattach |decimal_precision| (r maxperiod)
  "Compute the decimal precision of a rational number. Return 2 values. The first one is the number of
non-repeating digits. If maxperiod is negative, the second value is the period of the repeating
digits. Computing the period is expensive for rationals with large denominators. Therefore, if
maxperiod is non-negative, the second value is the minimum between the period and maxperiod+1.
In either case, if the second value is 0, the rational has a finite decimal representation."
  (multiple-value-bind (finp infp)
      (decimal-precision-of-rat r maxperiod)
    (pvs2cl_tuple finp infp)))

)))

;; This function makes a lisp representation of PVS objects suitable as inputs to format's directives.
;; {| a1,..,an |} becomes a1 ... an parameters to format
;; {| (: a1,..,an :) |} becomes a list to format's iterative directives
;; If e is a boolean, a string, a Mutable, or a Maybe, {| e |} becomes NIL if e is, respectively,
;; FALSE, the empty string, undef, or None. Otherwise, it returns its value. So, this makes {| e |}
;; suitable as input to the fomat's conditional directive ~@[...~].
(defun formatargs (e type)
  (cond
   ((is-print-type type '|Lisp| '|stdpvs|)
    (let ((ptype (find-supertype (type-value (car (dactuals type))))))
      (cond ((and (listp e) (adt-type-name? ptype) (equal (id ptype) '|list|))
	     (list (loop for ei in e
			 append (formatargs ei (type-value (car (actuals ptype)))))))
	    ((and (arrayp e) (tupletype? ptype))
	     (loop for ei across e
		   for ti in (types ptype)
		   append (formatargs ei ti)))
	    ((or (is-print-type ptype '|Mutable| '|stdprog|)
		 (is-print-type ptype '|Global| '|stdprog|)
		 (is-print-type ptype '|Global| '|stdglobal|))
	     (list (when (cdr e) (cadr e))))
	    ((and (adt-type-name? ptype) (eq (id ptype) '|Maybe|))
	     (list (when (slot-exists-p e '|val|)
		     (slot-value e '|val|))))
	    ((numberp e) (list (rat2double e)))
	    ((stringp e) (list (unless (string= e "") e)))
	    (t (list e)))))
   ((or (tc-eq (find-supertype type) *number*)
	(tc-eq (find-supertype type) *string-type*))
    (list e))
   (t (list (cl2pvs e type)))))

(defun stdprog-attachments ()

(eval '(attachments |stdprog|

(defattach |to_lisp_| (pvs (the-type :decl-formal |T|))
    "Encodes PVS object as a pair of Common Lisp object and CLOS type"
    (cons pvs (clos-type2str the-type)))

(defattach |from_lisp_| (cl (the-type :decl-formal |T|))
  "Decodes a pair of Common Lisp object and CLOS type into a PVS object"
  (let ((clos-type (pc-typecheck (pc-parse (cdr cl) 'type-expr))))
    (if (subtype-of? clos-type the-type)
	(car cl)
      (throw-pvsio-exc
       "stdexceptions.Lisp2PVS"
       (format nil " (type ~a is not of a sub-type of ~a)" clos-type the-type)))))

(defattach |new| ()
  "Creates a new mutable variable with an undefined value"
  (pvsio_new_gvar))

(defattach |ref| (value)
  "Creates a mutable variable and sets it to given value"
  (pvsio_ref_gvar value))

(defattach |def| (gvar value)
  "Sets mutable variable gvar to given value"
  (pvsio_def_gvar gvar value))

(defattach |val_lisp| (gvar)
  "Returns value of mutable variable. Throws exception UndefinedMutableVariable when undefined?(gvar)"
  (pvsio_val_gvar gvar))

(defattach |undef| (gvar)
  "Returns TRUE if mutable variable is undefined"
  (pvsio_undef_gvar gvar))

(defattach |reset| (gvar)
  "Sets mutable variable to undefined"
  (pvsio_reset_gvar gvar))

(defattach |push_lisp| (gvar value)
  "Pushes value to the top of the mutable variable and skips"
  (pvsio_push_gvar gvar value))

(defattach |pop_lisp| (gvar)
  "Pops value of the mutable variable and fails silently when mutable variable is undefined"
  (pvsio_pop_gvar gvar))

(defattach |name_of| (gvar)
  "Return name of Global variable GVAR. Issue an error if GVAR is a not
declared as a Global variable"
  (or (car gvar)
      (attach-error
       "Only mutable variables that are declared as Global have a name")))

(defattach |global?| (ref)
  "Return TRUE is mutable REF is a Global variable"
  (when (car ref) t))

)))

(define-condition pvsio-exception (simple-error)
  ((tag :accessor tag :initarg :tag)
   (val :accessor val :initarg :val)
   (mssg :accessor mssg :initarg :mssg))
  (:report
   (lambda (condition stream)
     (let* ((qid  (tag condition))
	    (root (cdr (split_thnm (car qid))))
	    (mid  (> (length qid) 2))
	    (id   (when (> (length qid) 1)
		    (cdr (split_thnm (car (last qid)))))))
     (format stream "[~a~:[~;::..~]~@[::~a~]]~@[ ~a~]"
	     root mid id (mssg condition))))))

(defun throw-pvsio-tag (tag val mssg)
  (error 'pvsio-exception :tag tag :val val :mssg  mssg))

(defun throw-pvsio-exc (exc val &optional mssg)
  (let ((tag (pvsio-eval-lisp (format nil "qid(~a)" exc)))
	(msg (or mssg (pvsio-funcall (format nil "say(~a)" exc) val))))
    (throw-pvsio-tag tag val msg)))

(define-condition pvsio-error (simple-error)
  ((message :accessor message :initarg :message :initform nil))
  (:report
   (lambda (condition stream)
     (format stream "[PVSioError]~@[ ~a~]" (message condition)))))

(define-condition pvsio-exit (simple-error) ())

(define-condition pvsio-return (simple-error)
  ((val :accessor val :initarg :val)
   (type :accessor type :initarg :type))
  (:report
   (lambda (condition stream)
     (let ((val-str (handler-case
			(str (cl2pvs (val condition) (pc-typecheck (type condition))))
		      (error (condition) (declare (ignore condition))))))
       (format stream "Value~@[ ~a~] was returned outside the scope of a function" val-str)))))

(define-condition pvsio-break (pvsio-return) ()
  (:report
   (lambda (condition stream)
     (let ((val-str (handler-case
			(str (cl2pvs (val condition) (pc-typecheck (type condition))))
		      (error (condition) (declare (ignore condition))))))
       (format stream "Value~@[ ~a~] was returned outside the scope of a loop" val-str)))))

(defun stdcatch-attachments ()

(eval '(attachments |stdcatch|

;; Check if list of strings tag1 is a prefix of the the list of strings tag2
(defun starts-with-tag (tag1 tag2)
  (or (null tag1)
      (and (car tag1) (car tag2)
	   (string= (car tag1) (car tag2))
	   (starts-with-tag (cdr tag1) (cdr tag2)))))

(defattach |catch_lift| (exctag f1 f2)
  "If F1 throws the exception tagged exctag, then evaluates f2(val). Otherwise, returns F1"
  (handler-case
      (pvs-funcall f1 *pvsio-dummy-val*)
    (pvsio-exception
     (condition)
     (if (starts-with-tag (slot-value exctag '|qid|)
			  (tag condition))
	 (let* ((exc (val condition)))
	   (pvs-funcall f2 exc))
       (error condition)))))

(defattach |throw_lisp| (exctag val mssg)
  "Throws the exception tagged EXCTAG using VAL and MSSG"
 (let ((tag (slot-value exctag '|qid|)))
   (throw-pvsio-tag tag val mssg)))

)))

(defun stdpvsio-attachments ()

(eval '(attachments |stdpvsio|

(defattach |help_pvs_attachment| (s)
  "Displays help for semantic attachment S"
  (or (help-pvs-attachment s) t))

(defattach |help_pvs_theory_attachments| (s)
  "Displays help for semantic attachments in theory S"
  (or (help-pvs-theory-attachments s) t))

(defattach |pvsio_version| ()
  "Shows current version of PVSio"
  *pvsio-version*)

(defattach |set_promptin| (s)
  "Change current PVSio input prompt to S"
  (when (setq *pvsio-promptin* s) t))

(defattach |set_promptout| (s)
  "Change current PVSio output prompt to S"
  (when (setq *pvsio-promptout* s) t))

)))

(defun stdsys-attachments ()

(eval '(attachments |stdsys|

(defattach |get_time| ()
  "Gets current system time"
  (multiple-value-bind (s mi h d mo y dow dst tz) (get-decoded-time)
    (the (simple-array *) (pvs2cl_record d dow dst h mi mo s tz y))))

(defattach |real_time| ()
   "Real time"
   (get-internal-real-time))

(defattach |run_time| ()
  "Run time"
  (get-internal-run-time))

(defattach |internal_time_units| ()
  "Units of internal time"
  internal-time-units-per-second)

(defattach |sleep| (n)
  "Sleeps N seconds"
  (or (sleep n) t))

(defattach |get_env| (name default)
  "Gets environment variable NAME. Returns DEFAULT if undefined"
  (or (environment-variable (string name)) default))

(defattach |system_call| (call)
  "Makes system CALL and returns status and output string"
  (let ((output (extra-system-call call)))
    (pvs2cl_record (car output) (cdr output))))

)))

(defun initialize-prelude-attachments ()
  (stdpvs-attachments)
  (stdprog-attachments)
  (stdcatch-attachments)
  (stdmath-attachments)
  (stdchar-attachments)
  (stdstr-attachments)
  (stdio-attachments)
  (stdpvsio-attachments)
  (stdsys-attachments))
